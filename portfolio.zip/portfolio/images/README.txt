Place your photo here as profile.jpg (portrait, about 800x1000 px).
Place your resume in the site folder as resume.pdf (next to index.html).
